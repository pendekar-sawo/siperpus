<div class="col-sm-9">
  <h4><i class="glyphicon glyphicon-print"></i> Cetak Laporan</h4>
  <hr>	
</div>
<div class="col-md-9">
	<div class="panel panel-info">
		<div class="panel-heading">
			<div class="panel-title">Laporan</div>
		</div>

		<div class="panel-body">
		
		<div class="list-group">		  
		  <a href="../print-anggota.php" target="_blank" class="list-group-item"><span class="fa fa-users"></span> Laporan Anggota</a>
		  <a href="../print-buku.php" target="_blank" class="list-group-item"><span class="fa fa-book"></span> Laporan Buku</a>
		  <a href="../print-pinjam.php" target="_blank" class="list-group-item"><span class="glyphicon glyphicon-save-file"></span> Laporan Peminjaman</a>
		</div>
    
		</div>

	</div>
</div>

