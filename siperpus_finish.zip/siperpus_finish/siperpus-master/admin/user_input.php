<?php 
include_once '../inc/class.perpus.php';
$user = new user;

include "config.php";

if (isset($_POST['btn-save'])) {
	$nama = $_POST['nama'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$password = md5($password);
	$email = $_POST['email'];
	$level = $_POST['level'];

	// Ambil data gambar dari form
	$nama_file = $_FILES['foto']['name'];
	$ukuran_file = $_FILES['foto']['size'];
	$tipe_file = $_FILES['foto']['type'];
	$tmp_file = $_FILES['foto']['tmp_name'];

	// set path folder tempat menyimpan gambar
	$imgExt = strtolower(pathinfo($nama_file,PATHINFO_EXTENSION));
	$userpic = rand(0,9999).".".$imgExt;
	$dest = "../images/".$userpic; //$_SERVER['DOCUMENT_ROOT'].
	// Cek apakah tipe file yg di upload adalah JPG/JPEG/PNG
	if ($tipe_file == "image/jpeg" || $tipe_file == "image/png") {
		# jika tipe file JPG/JPEG/PNG, maka lakukan:
		// Cek apakah ukuran file sama atau lebih kecil dari 1MB
		if ($ukuran_file <= 1000000) {
			# jika ukuran file kurang dari sama dengan 1MB, lakukan :
			// proses upload
			//$move = move_uploaded_file($tmp_file, "../images/".$dest);
			if (move_uploaded_file($tmp_file, "../images/".$dest)) { // cek apakah gambar berhasil di upload
				# jika gambar berhasil di upload, lakukan :
				//  proses simpan ke database
				//ini sqlnya---
				//INSERT INTO `tbl_user` (`id`, `nama`, `username`, `password`, `email`, `foto`, `level`) VALUES ('4', 'sawo2', 'sawo2', 'ee11cbb19052e40b07aac0ca060c23ee', 'brofista12@gmail.com', 'perpus2.jpg', 'user');
				if ($user->create($nama,$username,$password,$email,$userpic,$level)) {
					header('location:?page=user&msg=success');
					echo "<script> alert('Input USER berhasil') </script>";
				}			
			}else{
				// jika gambar gagal di upload
				echo "<script> alert('Maaf, input USER gagal') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=user'>";
			}
		}else{
			// jika ukuran lebih dari 1MB
			echo "<script> alert('Maaf, Ukuran gambar yang diupload tidak boleh lebih dari 1MB') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=user'>";
		}
	}else{
		//jika tipe file yg diupload bukan JPG/JPEG.PNG, lakukan :
		echo "<script> alert('Maaf, Tipe gambar yang diupload harus JPG / JPEG / PNG.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=user'>";
	}

}
?>
<div class="col-sm-9">
	<h4><i class="glyphicon glyphicon-user"></i> Input Data User</h4>
	<hr>
</div>

<div class="col-md-9">
	
	<form method="post" enctype="multipart/form-data">
		<table class="table table-bordered">
			<tr>
				<td>Nama Lengkap</td>
				<td><input class="form-control" type="text" name="nama" placeholder="Nama Lengkap.." required></td>
			</tr>
			<tr>
				<td>Username</td>
				<td><input class="form-control" type="text" name="username" placeholder="Username.." required></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input class="form-control" type="password" name="password" placeholder="Password.." required></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input class="form-control" type="text" name="email" placeholder="Email.." required></td>
			</tr>
			<tr>
				<td>Foto</td>
				<td><input type="file" name="foto"></td>
			</tr>
			<tr>
				<td>Level</td>
				<td>
					<select class="form-control" name="level" style="width: 200px">
						<option>Pilih Level</option>
						<option value="admin">Administrator</option>
						<option value="staff">Staff</option>
						<option value="user">User</option>
					</select>
				</td>
			</tr>

			<tr>
				<td colspan="2">
					<button type="submit" class="btn btn-primary" name="btn-save">
						<span class="glyphicon glyphicon-save"></span> Simpan
					</button>
					<a href="?page=user" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp;Kembali</a>
				</td>
			</tr>
		</table>
	</form>

</div>