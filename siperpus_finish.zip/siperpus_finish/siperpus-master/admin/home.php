<!--<div class="col-sm-9">
<h1>Bergelud? tengah malam seperti ini kau mau bergelud?</h1>
<h2>OYY! ini perpus apaan?!</h2>
<h3>serius, ini apaan?</h3>
</div>

-->

<?php 
		 include '../inc/class.perpus.php';
         $anggota = new anggota;
         $buku = new buku;
         $user = new user;
         $query1 = "SELECT * FROM tbl_anggota";
         $query2 = "SELECT * FROM tbl_buku";
         $query3 = "SELECT * FROM tbl_user";
        //  $anggota->jumlah($query);	
        //  $buku->jumlah($query);	
        //  $user->jumlah($query);
                
?>


<div class="col-sm-9">

      <h4 class="glyphicon glyphicon-home"> Home</h4>
      <hr>

      
      <div class="panel panel-default">
          <div class="panel-heading">

          <div class="row">
              <div class="col-lg-12">
                  Dashboard
              </div>
              <!-- /.col-lg-12 -->
          </div>
          <!-- /.row -->

          </div>

          <div class="panel-body">

              <div class="row">
                  <div class="col-lg-4 col-md-6">
                      <div class="panel panel-primary">
                          <div class="panel-heading">
                              <div class="row">
                                  <div class="col-xs-3">
                                      <!-- <i class="fa fa-comments fa-5x"></i> -->
                                      <i class="fa fa-users fa-5x"></i>
                                  </div>
                                  <div class="col-xs-9 text-right">
                                      <div class="huge"><?php $anggota->jumlah($query1); ?></div>
                                      <!-- <b> Anggota</b> -->
                                      <div>Anggota</div>
                                  </div>
                              </div>
                          </div>
                          <a href="?page=anggota">
                              <div class="panel-footer">
                                  <span class="pull-left">Lihat Anggota</span>
                                  <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                  <div class="clearfix"></div>
                              </div>
                          </a>
                      </div>
                  </div>

                  <div class="col-lg-4 col-md-6">
                      <div class="panel panel-green">
                          <div class="panel-heading">
                              <div class="row">
                                  <div class="col-xs-3">
                                      <i class="fa fa-book fa-5x"></i>
                                  </div>
                                  <div class="col-xs-9 text-right">
                                      <div class="huge"><?php $buku->jumlah($query2); ?></div>
                                      <div>Buku</div>
                                  </div>
                              </div>
                          </div>
                          <a href="?page=buku">
                              <div class="panel-footer">
                                  <span class="pull-left">Lihat Buku</span>
                                  <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                  <div class="clearfix"></div>
                              </div>
                          </a>
                      </div>
                  </div>

                  <div class="col-lg-4 col-md-6">
                      <div class="panel panel-yellow">
                          <div class="panel-heading">
                              <div class="row">
                                  <div class="col-xs-3">
                                      <i class="fa fa-user fa-5x"></i>
                                  </div>
                                  <div class="col-xs-9 text-right">
                                      <div class="huge"><?php $user->jumlah($query3); ?></div>
                                      <div>Users</div>
                                  </div>
                              </div>
                          </div>
                          <a href="?page=user">
                              <div class="panel-footer">
                                  <span class="pull-left">Lihat User</span>
                                  <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                  <div class="clearfix"></div>
                              </div>
                          </a>
                      </div>
                  </div>

                 
              </div>
              <!-- /.row -->

          </div>

      </div>


      

</div>

        <!-- jQuery -->
        <script src="../css/template/backend/sbadmin/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="../css/template/backend/sbadmin/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="../css/template/backend/sbadmin/vendor/metisMenu/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="../css/template/backend/sbadmin/vendor/raphael/raphael.min.js"></script>
<script src="../css/template/backend/sbadmin/vendor/morrisjs/morris.min.js"></script>
<script src="../css/template/backend/sbadmin/data/morris-data.js"></script>

<!-- Custom Theme JavaScript -->
<script src="../css/template/backend/sbadmin/dist/js/sb-admin-2.js"></script>


<!-- test jquery -->
<script type="text/javascript">

    $(document).ready(function(){
        // alert('test jquery');
        
    });
</script>







