<?php 
		 include '../inc/class.perpus.php';
         $anggota = new anggota;
         $buku = new buku;
         $transaksi = new transaksi;
         $query1 = "SELECT * FROM tbl_anggota";
         $query2 = "SELECT * FROM tbl_buku";
         $query = "SELECT * FROM tbl_transaksi WHERE status='Pinjam' ORDER BY id";
        //  $anggota->jumlah($query);	
        //  $buku->jumlah($query);	
        //  $user->jumlah($query);
                
?>
<div class="col-sm-9">

<h4 class="glyphicon glyphicon-home"> Home</h4>
<hr>


<div class="panel panel-default">
    <div class="panel-heading">

    <div class="row">
        <div class="col-lg-12">
            Dashboard
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    </div>

    <div class="panel-body">

        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <!-- <i class="fa fa-comments fa-5x"></i> -->
                                <i class="fa fa-book fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php $buku->jumlah($query2); ?></div>
                                <!-- <b> Anggota</b> -->
                                <div>Buku</div>
                            </div>
                        </div>
                    </div>
                    <a href="?page=buku">
                        <div class="panel-footer">
                            <span class="pull-left">Lihat Buku</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-users fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php $anggota->jumlah($query1); ?></div>
                                <div>Anggota</div>
                            </div>
                        </div>
                    </div>
                    <a href="?page=anggota">
                        <div class="panel-footer">
                            <span class="pull-left">Lihat Anggota</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="panel panel-yellow">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-signal fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php $transaksi->jumlah($query); ?></div>
                                <div>Peminjaman</div>
                            </div>
                        </div>
                    </div>
                    <a href="?page=pinjam">
                        <div class="panel-footer">
                            <span class="pull-left">Lihat Peminjaman</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="panel panel-info2">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-file-text   fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge">Laporan</div>
                                <!-- <div>Pengembalian</div> -->
                            </div>
                        </div>
                    </div>
                    <a href="?page=laporan">
                        <div class="panel-footer">
                            <span class="pull-left">Cetak Laporan</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="panel panel-red">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-power-off fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge">Logout</div>
                            </div>
                        </div>
                    </div>
                    <a href="?page=logout" class="text-danger2">
                        <div class="panel-footer">
                            <span class="pull-left">Logout here...</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            
        </div>
        <!-- /.row -->

    </div>

</div>




</div>

  <!-- jQuery -->
  <script src="../css/template/backend/sbadmin/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="../css/template/backend/sbadmin/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="../css/template/backend/sbadmin/vendor/metisMenu/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="../css/template/backend/sbadmin/vendor/raphael/raphael.min.js"></script>
<script src="../css/template/backend/sbadmin/vendor/morrisjs/morris.min.js"></script>
<script src="../css/template/backend/sbadmin/data/morris-data.js"></script>

<!-- Custom Theme JavaScript -->
<script src="../css/template/backend/sbadmin/dist/js/sb-admin-2.js"></script>


<!-- test jquery -->
<script type="text/javascript">

$(document).ready(function(){
  // alert('test jquery');
  
});
</script>

