<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin | PerpusSawo</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">

  <!-- Bootstrap Core CSS -->
<link href="../css/template/backend/sbadmin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap Core CSS -->
<link href="../css/template/backend/sbadmin/css/datepicker.css" rel="stylesheet">


<!-- Custom Isi CSS -->
<link href="../css/template/backend/sbadmin/vendor/bootstrap/css/custom.css" rel="stylesheet">

<!-- MetisMenu CSS -->
<link href="../css/template/backend/sbadmin/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

<!-- DataTables CSS -->
<link href="../css/template/backend/sbadmin/vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

<!-- DataTables Responsive CSS -->
<link href="../css/template/backend/sbadmin/vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="../css/template/backend/sbadmin/dist/css/sb-admin-2.css" rel="stylesheet">

<!-- Morris Charts CSS -->
<link href="../css/template/backend/sbadmin/vendor/morrisjs/morris.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="../css/template/backend/sbadmin/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>




<!-- test jquery -->
<script type="text/javascript">

    $(document).ready(function(){
        // alert('test jquery');
        
    });
</script>

  




  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: auto}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;}
    }
  </style>
</head>
<body class="hold-transition skin-green sidebar-mini  ">
<?php 
session_start();
if(!isset($_SESSION['nama'])|| $_SESSION['level'] != "admin"){
  echo "<script>alert('Silahkan login terlebih dahulu')</script>";
  echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
}
else{

  include_once 'head.php';
?>

<div class="container-fluid">

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <h5>Welcome : <font color="red"><?php echo $_SESSION['nama']; ?></font></h5>      
      <ul class="nav nav-pills nav-stacked">
        <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
        <li><a href="?page=buku"><i class="glyphicon glyphicon-book"></i> Buku</a></li>
        <li><a href="?page=anggota"><i class="fa fa-users"></i> Anggota</a></li>
        <!-- <li><a href="?page=transaksi"><i class="glyphicon glyphicon-random"></i> Transaksi</a></li>
        <li><a href="?page=laporan"><i class="glyphicon glyphicon-file"></i> Laporan</a></li> -->
        <li><a href="?page=user"><i class="glyphicon glyphicon-user"></i> User</a></li>
      </ul><br>
    </div>

    <?php 
    error_reporting(0);
    switch ($_GET['page']) {
      // menu buku
      case 'buku':
        include "buku_data.php";
        break;
      case 'detil-buku':
        include "buku_detil.php";
        break;
      case 'buku_input':
        include "buku_input.php";
        break;
      case 'buku_edit':
        include "buku_edit.php";
        break;
      case 'buku_search':
        include "buku_search.php";
        break;
      case 'detil-buku':
        include "buku_detil.php";
        break;

      // menu anggota
      case 'anggota':
        include "anggota_data.php";
        break;
      case 'anggota_input':
        include "anggota_input.php";
        break;
      case 'anggota_edit':
        include "anggota_edit.php";
        break;
      case 'anggota_search':
        include "anggota_search.php";
        break;
      case 'detil-anggota':
        include 'anggota_detil.php';
        break;

      // menu user
      case 'user':
        include "user_data.php";
        break;
      case 'user_input':
        include "user_input.php";
        break;
      case 'user_edit':
        include "user_edit.php";
        break;
      case 'user_search':
        include "user_search.php";
        break;
      case 'detil-user':
        include "user_detil.php";
        break;


      case 'logout':
        include "../logout.php";
        break;
      
      default:
        include "home.php";
        break;
    }
    ?>
    
  </div>
</div>
</div>
<br>
<footer class="container-fluid">
  <p><i class="fa fa-github"></i> tsanpride | pendekar-sawo <a href="index.php" target="_blank">Sistem Informasi Perpustakaan</a></p>
</footer>
<?php } ?>
</body>
</html>

