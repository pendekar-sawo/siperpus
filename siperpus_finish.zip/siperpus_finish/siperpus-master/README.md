# siperpus
sistem informasi perpustakaan dengan PHP dan bootstrap

<hr>
Menu
- Akun
	- admin	(pwd: admin)
	- staff (pwd: staff)
- Buku
	- tampil
	- edit
	- cari
	- hapus
- Anggota
	- tampil
	- edit
	- cari
	- hapus
- User
	- tampil
	- edit
	- cari
	- hapus
