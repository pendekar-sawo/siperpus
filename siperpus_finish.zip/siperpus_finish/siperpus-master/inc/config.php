<?php 

// $host = 'localhost';
// $username = 'root';
// $password = '';
// $dbname = 'db_perpus';

$db_con = new PDO('mysql:host=localhost;dbname=db_perpus', 'root', '');
//$connect = mysqli_connect($host, $username, $password, $database);
$config['base_url'] = 'http://localhost/perpus-master/';

?>
